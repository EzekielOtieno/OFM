```python
import joblib
import numpy as np
from pathlib import Path
from PIL import Image
import cv2
import time
from openflexure_microscope_client import MicroscopeClient

# ================================
# 1. Initialize microscope
# ================================
microscope = MicroscopeClient("172.20.69.53")

# ================================
# 2. Load SVM model and scaler
# ================================
model_path = r"C:\Users\Ezekiel\Desktop\model trained\New folder\signed_step_size_model.pkl"
scaler_path = r"C:\Users\Ezekiel\Desktop\model trained\New folder\scaler.joblib"

regressor = joblib.load(model_path)
scaler = joblib.load(scaler_path)

# ================================
# 3. Output folder
# ================================
output_dir = Path.home() / "Desktop" / "SVM" / "different objective lense times 40" / "varince2"
output_dir.mkdir(parents=True, exist_ok=True)

# ================================
# 4. Get current position and capture initial image
# ================================
initial_pos = microscope.position
Z_prev = initial_pos['z']

# 🔍 Capture and save initial (unfocused) image
image = microscope.grab_image()
image_array = np.array(image)
initial_image_path = output_dir / "initial_unfocused_image.png"
Image.fromarray(image_array).save(initial_image_path)
print(f"🟡 Initial (unfocused) image saved at: {initial_image_path}")

# ✅ Compute variance (initial)
gray = cv2.cvtColor(image_array, cv2.COLOR_RGB2GRAY)
variance = cv2.Laplacian(gray, cv2.CV_64F).var()
d_variance = 0.0  # Baseline or static if no previous step

# ================================
# 5. Predict step and move (with timer)
# ================================
features = np.array([[Z_prev, variance, d_variance]])
X_scaled = scaler.transform(features)

predicted_step = regressor.predict(X_scaled)[0]
print(f"🔁 Predicted step size: {predicted_step:.2f} steps")

start_time = time.time()

target_z = Z_prev + int(predicted_step)
microscope.move({'x': initial_pos['x'], 'y': initial_pos['y'], 'z': target_z})
time.sleep(1.5)

# ================================
# 6. Capture and save final (focused) image
# ================================
final_image = microscope.grab_image()
final_image_array = np.array(final_image)
final_image_path = output_dir / "final_focused_image.png"
Image.fromarray(final_image_array).save(final_image_path)

end_time = time.time()

# ✅ Compute variance (final)
gray_final = cv2.cvtColor(final_image_array, cv2.COLOR_RGB2GRAY)
variance_final = cv2.Laplacian(gray_final, cv2.CV_64F).var()

# ================================
# 7. Report results
# ================================
elapsed_time = end_time - start_time

print(f"✅ Final focused image saved at: {final_image_path}")
print(f"⏱️ Time taken to move and capture: {elapsed_time:.2f} seconds")
print(f"📊 Laplacian Variance - Before: {variance:.2f}, After: {variance_final:.2f}")

```
